<!-- view/Alert-->
<div id="ajax_msg" class="alert alert-success">some alerts</div>