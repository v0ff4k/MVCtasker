<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src='//cdnjs.cloudflare.com/ajax/libs/jquery.form/3.51/jquery.form.min.js' type='text/javascript'></script>
<!-- tab sorter and paginator -->
<script type="text/javascript" src="//tablesorter.com/__jquery.tablesorter.min.js"></script>
<script type="text/javascript" src="//tablesorter.com/addons/pager/jquery.tablesorter.pager.js"></script>


<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/4.0.2/bootstrap-material-design.umd.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"
        integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS"
        crossorigin="anonymous"></script>

<!-- last Javascript -->
<script src="js/material.js"></script>
<script src="js/ripples.js"></script>
<script src="js/app.js"></script>
<script> $.material.init(); </script>
</body>
</html>
